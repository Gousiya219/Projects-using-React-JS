import React from "react";
import { Navbar, Nav, Container as BootstrapContainer } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";

function NavBarComponent({ slotDate }) {
  return (
    <Navbar bg="black" variant="dark" expand="lg" fixed="top" style={{ boxShadow: "0 4px 8px rgba(0,0,0,0.2)", padding: "10px 20px" }}>
      <BootstrapContainer>
        <Navbar.Brand href="/" style={{ fontWeight: "bold", fontSize: "1.5rem", letterSpacing: "1px" }}>
          Play Zone
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="ms-auto" style={{ alignItems: "center" }}>
            {slotDate && (
              <Navbar.Text style={{ color: "#ffeb3b", fontWeight: "bold", marginRight: "15px" }}>
                Slot Date: {slotDate}
              </Navbar.Text>
            )}
            <Navbar.Brand href="/">
              <img
                src="./images/BlackBall.jpg"
                width="50"
                height="50"
                className="d-inline-block align-top"
                alt="Logo"
                style={{ borderRadius: "50%", boxShadow: "0 2px 6px rgba(0,0,0,0.3)" }}
              />
            </Navbar.Brand>
          </Nav>
        </Navbar.Collapse>
      </BootstrapContainer>
    </Navbar>
  );
}

export default NavBarComponent;
