import React from 'react'

function Test({name, surname, fname, lname}) {
  return (
    <div>
      test124 {name} , {surname}
    </div>
  )
}

export default Test
