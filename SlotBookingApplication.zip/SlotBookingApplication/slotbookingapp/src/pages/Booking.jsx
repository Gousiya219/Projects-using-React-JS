import {
  Box,
  Container,
  Stack,
  Typography,
  Button,
  TextField,
  Grid,
  fabClasses,
} from "@mui/material";
import React, { useState } from "react";
import { useParams } from "react-router-dom";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import NavBarComponent from "../components/NavBarComponent";
import dayjs from "dayjs";
import { bookings } from "../data/bookingslots";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function Booking() {
  const { sportName } = useParams();
  const [activeButton, setActiveButton] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const today = new Date().toISOString().split("T")[0];
  const futureDate = dayjs().add(1, "day").format("YYYY-MM-DD");
  const navigate = useNavigate();

  const [selectedDate, setSelectedDate] = useState("");
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");
  const handleClick = (id) => {
    if (activeButton === id) {
      setActiveButton(!activeButton);
    } else {
      setActiveButton(id);
    }
  };
  const handleBookingSave = () => {
    const newBooking = {
      BookingId: Math.floor(Math.random() * 1000) + 300, // Generates a random Booking ID
      SlotDate: selectedDate,
      Name: name,
      ContactNumber: contact,
      Game: sportName,
      Slots: futureDate// Gets the selected time slot
    };

    axios
      .post("http://localhost:8000/BookedSlots", newBooking)
      .then((response) => {
        console.log("Booking saved successfully:", response.data);
        navigate("/SearchPage"); // Redirect after successful booking
      })
      .catch((error) => {
        console.error("Error saving booking:", error);
        setErrorMessage("Failed to save booking. Please try again.");
      });
  };

  const handleBookNow = (activeButton) => {
    const validateSlotSelected = validateSlotSelection(activeButton);
    if (validateSlotSelected) {
      const validName = validateName(name);
      if (validName) {
        const validNumber = validatePhoneNumber(contact);
        if (validName && validNumber && selectedDate != "") {
          setErrorMessage("");
          handleBookingSave();
          navigate("./SearchPage");
        }
      }
    }
  };
  const validateSlotSelection = (activeButton) => {
    if (activeButton === false) {
      setErrorMessage("Please select slot first");
      return false;
    }
    return true;
  };
  const validateName = (name) => {
    const nameRegex = /^[A-Za-z\s]+$/;
    if (!nameRegex.test(name)) {
      setErrorMessage("Invalid Input");
      return false;
    }
    return true;
  };

  const validatePhoneNumber = (contact) => {
    const phoneRegex = /^[0-9]{10}$/; // Allows exactly 10 digits
    if (!phoneRegex.test(contact)) {
      setErrorMessage("Invalid Contact Number: Must be 10 digits.");
      return false;
    }
    return true;
  };

  return (
    <Stack sx={{ textAlign: "center", alignItems: "center" }}>
      <NavBarComponent slotDate={selectedDate} />
      <Container
        sx={{
          maxWidth: "600px",
          mt: 1,
          mb: 1,
          ml: -2,
          p: 3,
          borderRadius: 3,
          backgroundColor: "#f4f4f4",
          boxShadow: 3,
        }}
      >
        <Typography variant="h5" fontWeight="bold" sx={{ mb: 2 }}>
          Book a Slot for {sportName}
        </Typography>

        {/* Date Picker Box */}
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            pb: 2,
          }}
        >
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DatePicker
              label="Select Date for Slot Booking"
              value={dayjs(selectedDate)}
              disablePast
              onChange={(newDate) =>
                setSelectedDate(dayjs(newDate).format("YYYY-MM-DD"))
              }
              sx={{
                color: "blue",
                backgroundColor: "blue",
                borderRadius: 2,
                "& .MuiInputBase-root": {
                  backgroundColor: "#fff",
                  borderRadius: 2,
                },
              }}
            />
          </LocalizationProvider>
        </Box>
        {selectedDate === "" && (
          <Typography
            variant="body1"
            sx={{
              mt: 2,
              p: 1.5,
              // backgroundColor: "#ffcccc",
              color: "blue",
              fontWeight: "bold",
              borderRadius: 2,
            }}
          >
            ⚠ Please select the date to book the slot.
          </Typography>
        )}
        {selectedDate === today && (
          <Typography
            variant="body1"
            sx={{
              mt: 2,
              p: 1.5,
              backgroundColor: "#ffcccc",
              color: "red",
              fontWeight: "bold",
              borderRadius: 2,
            }}
          >
            ⚠ Bookings have been closed. Book your slot for {futureDate}
          </Typography>
        )}

        {dayjs(selectedDate).isAfter(dayjs().add(1, "day"), "day") && (
          <Typography
            variant="body1"
            sx={{
              mt: 2,
              p: 1.5,
              backgroundColor: "#ffcccc",
              color: "red",
              fontWeight: "bold",
              borderRadius: 2,
            }}
          >
            ⚠ Booking is not opened yet
          </Typography>
        )}

        {/* Time Slots */}
        <Grid container spacing={2} justifyContent="center" sx={{ mt: 2 }}>
          {bookings.map((item, id) => (
            <Grid item key={id}>
              <Button
                onClick={() => handleClick(id)}
                variant="contained"
                sx={{
                  backgroundColor: activeButton === id ? "blue" : "#4caf50",
                  color: "white",
                  minWidth: 120,
                  minHeight: 50,
                }}
              >
                {item.time}
              </Button>
            </Grid>
          ))}
        </Grid>

        {/* User Input Fields */}
        <Box sx={{ mt: 3 }}>
          <TextField
            label="Enter Your Name"
            variant="outlined"
            fullWidth
            sx={{ mb: 2, backgroundColor: "#fff" }}
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <TextField
            label="Enter Your Contact No"
            variant="outlined"
            fullWidth
            sx={{ mb: 2, backgroundColor: "#fff" }}
            value={contact}
            onChange={(e) => setContact(e.target.value)}
          />
          {errorMessage && ( // ✅ Styled Error Message
            <Typography
              sx={{
                color: "red",
                backgroundColor: "#ffe6e6",
                p: 1,
                borderRadius: 2,
                fontWeight: "bold",
                mt: 1,
              }}
            >
              {errorMessage}
            </Typography>
          )}

          <Button
            variant="contained"
            sx={{
              backgroundColor: "#1976d2",
              width: "100%",
              p: 1.5,
            }}
            onClick={() => handleBookNow(activeButton)}
          >
            Book Now
          </Button>
        </Box>
      </Container>
    </Stack>
  );
}

export default Booking;
