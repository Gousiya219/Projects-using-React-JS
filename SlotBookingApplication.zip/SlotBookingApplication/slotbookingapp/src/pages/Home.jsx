import React, { useState } from "react";
import {
  Card,
  CardActions,
  CardContent,
  CardMedia,
  Button,
  Typography,
  Box,
  Container,
  Stack,
} from "@mui/material";
import Navbar from "react-bootstrap/Navbar";
import { Nav, Container as BootstrapContainer } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import Booking from "./Booking";
import NavBarComponent from "../components/NavBarComponent";
const sports = [
  { name: "Basketball", image: "./images/basketball.jpg" },
  { name: "Chess", image: "./images/chess.jpeg" },
  { name: "Cricket", image: "./images/Cricket.jpeg" },
  { name: "Football", image: "./images/football.jpg" },
];

function Home() {
  const [sportName, setSportName] = useState("");
  const navigate = useNavigate();
  const handleBookNow = (name) => {
    console.log("sportName", name);
    setSportName(name);
    navigate(`/BookingPage/${name}`);
  };
  const handleCheckBookingClick = () => {
    navigate("/SearchPage");
  };
  return (
    <Stack>
      <NavBarComponent />
      <Container sx={{ mt: 4, textAlign: "center" }}>
        <Box
          sx={{
            display: "flex",
            flexWrap: "nowrap",
            overflowX: "auto",
            gap: 3,
            justifycontnet: "center",
            pb: 2,
          }}
        >
          {sports.map((sport, index) => (
            <Card
              key={index}
              sx={{
                minWidth: 250,
                maxWidth: 300,
                backgroundColor: "white",
                textAlign: "center",
                boxShadow: 3,
                borderRadius: 2,
                height: 300,
                flexShrink: 0, // Prevents shrinking in flexbox
              }}
            >
              <CardMedia
                component="img"
                sx={{ height: 120, width: "auto", margin: "0 auto", pt: 2 }}
                image={sport.image}
                alt={sport.name}
              />
              <CardContent>
                <Typography gutterBottom variant="h6">
                  {sport.name}
                </Typography>
              </CardContent>
              <CardActions sx={{ justifyContent: "center" }}>
                <Button
                  size="medium"
                  variant="contained"
                  sx={{
                    backgroundColor: "black",
                    color: "white",
                    "&:hover": { backgroundColor: "#333" },
                  }}
                  onClick={() => handleBookNow(sport.name)}
                >
                  Book Now
                </Button>
              </CardActions>
            </Card>
          ))}
        </Box>

        {/* Booking button below container */}
        <Button
          size="large"
          variant="contained"
          sx={{
            backgroundColor: "black",
            color: "white",
            "&:hover": { backgroundColor: "#333" },
            mt: 3,
          }}
          onClick={handleCheckBookingClick}
        >
          Check Your Booking!!
        </Button>
      </Container>
    </Stack>
  );
}

export default Home;
