import { Box, Container, TextField, Typography } from "@mui/material";
import React, { useState, useEffect } from "react";
import { Nav, Container as BootstrapContainer, Stack } from "react-bootstrap";
import Navbar from "react-bootstrap/Navbar";
import NavBarComponent from "../components/NavBarComponent";
import { DataGrid } from "@mui/x-data-grid";
import Paper from "@mui/material/Paper";
import axios from "axios";

function Search() {
  const [rows, setRows] = useState([]);
  const [searchedData, setSearchedData] = useState(rows);

  useEffect(() => {
    axios
      .get("http://localhost:8000/BookedSlots")
      .then((response) => {
        setRows(response.data);
        setSearchedData(response.data);
      })
      .catch((error) => {
        console.log("Error Fetching data", error);
      });
  }, []);
  const columns = [
    { field: "BookingId", headerName: "Booking Id" },
    { field: "SlotDate", headerName: "Slot Date" },
    { field: "Name", headerName: "Name" },
    { field: "ContactNumber", headerName: "ContactNumber" },
    { field: "Game", headerName: "Game" },
    { field: "Slots", headerName: "Slots" },
  ];

  const paginationModel = { page: 0, pageSize: 5 };
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <Stack sx={{ textAlign: "center", alignItems: "center" }}>
      <NavBarComponent />
      <Box sx={{ mt: 15 }}>
        <TextField
          label="Enter Booking Id"
          variant="outlined"
          sx={{ mb: 5, ml: 10, backgroundColor: "#fff", height: "10" }}
          onChange={(e) => {
            setSearchedData(
              rows.filter((row) =>
                row.BookingId.toString().includes(e.target.value)
              )
            );
          }}
        />
      </Box>
      {searchedData.length === 0 ? (
        <Typography variant="h6" color="white" sx={{ mt: 10,ml: 10 }}>No Bookings are present!!</Typography>
      ) : (
        <Paper sx={{ height: 400, width: "100%" }}>
          <DataGrid
            rows={searchedData}
            columns={columns}
            initialState={{ pagination: { paginationModel } }}
            pageSizeOptions={[5, 10]}
            checkboxSelection
            sx={{ border: 0 }}
          />
        </Paper>
      )}
    </Stack>
  );
}

export default Search;
