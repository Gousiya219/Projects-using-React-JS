import { Route, Routes } from "react-router-dom";
import "./App.css";
import Booking from "./pages/Booking";
import Home from "./pages/Home";
import Search from "./pages/Search";


function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="/BookingPage/:sportName" element={<Booking/>}></Route>
        <Route path="/SearchPage" element={<Search />}></Route>
      </Routes>

      {/* <Test surname="Acchukatla" name="Gousiya" lname="adasd"/> */}
    </div>
  );
}

export default App;
