export const bookings = [
  {
    time: "09.00 AM - 10.00 AM",
    id: 1,
  },
  {
    time: "10.00 AM - 11.00 AM",
    id: 2,
  },
  {
    time: "11.00 AM - 12.00 AM",
    id: 3,
  },
  {
    time: "12.00 AM - 01.00 PM",
    id: 4,
  },
  {
    time: "01.00 PM - 02.00 PM",
    id: 5,
  },
  {
    time: "02.00 PM-03.00 PM",
    id: 6,
  },
  {
    time: "03.00 PM - 04.00 PM",
    id: 7,
  },
  {
    time: "04.00 PM - 05.00 PM",
    id: 8,
  },
  {
    time: "05.00 PM - 06.00 PM",
    id: 9,
  },
];
