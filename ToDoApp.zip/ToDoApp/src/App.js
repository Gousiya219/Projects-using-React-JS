import ToDoApp from "./Components/ToDoApp";

function App() {
  return (
    <div className="App">
      <ToDoApp />
    </div>
  );
}

export default App;
