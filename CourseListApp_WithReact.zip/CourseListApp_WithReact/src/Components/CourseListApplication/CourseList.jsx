import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const CourseList = () => {
  const [courses, setCourses] = useState([]);
  const url = "http://localhost:8000/CoursesJSONData";

  useEffect(() => {
    axios.get(url).then((response) => {
      setCourses(response.data);
    });
  }, []);

  return (
    <div style={{ padding: "20px", maxWidth: "600px", margin: "auto", fontFamily: "Arial, sans-serif" }}>
      <h2 style={{ textAlign: "center", color: "#4CAF50", marginBottom: "20px" }}>Available Courses</h2>
      {courses.map((course) => (
        <div
          key={course.id}
          style={{
            border: "1px solid #ddd",
            borderRadius: "5px",
            padding: "15px",
            marginBottom: "10px",
            backgroundColor: "#f9f9f9",
            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <span style={{ fontWeight: "bold", fontSize: "16px" }}>{course.courseName}</span>
          <Link to={`/user-details-form`} style={{ textDecoration: "none" }}>
            <button
              style={{
                padding: "8px 12px",
                backgroundColor: "#4CAF50",
                color: "white",
                border: "none",
                borderRadius: "3px",
                cursor: "pointer",
                fontSize: "14px",
              }}
            >
              Enquire
            </button>
          </Link>
        </div>
      ))}
    </div>
  );
};

export default CourseList;
