import axios from "axios";
import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

function UserDetailsForm() {
  const { courseId } = useParams();
  const navigate = useNavigate();

  const [userDetails, setUserDetails] = useState({
    name: "",
    email: "",
    message: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserDetails({ ...userDetails, [name]: value });
  };

  const handleSaveEnquiry = (e) => {
    e.preventDefault();
    const newEnquiry = { ...userDetails, courseId };
    axios
      .post("http://localhost:8000/enquiries", newEnquiry)
      .then(() => {
        alert("Enquiry submitted successfully!");
        navigate("/user-enquiries");
      })
      .catch((error) => {
        console.error("Error submitting enquiry:", error);
      });
  };

  return (
    <div
      style={{
        maxWidth: "400px",
        margin: "auto",
        padding: "50px",
        border: "1px solid #ddd",
        borderRadius: "5px",
        backgroundColor: "#f9f9f9",
        boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
        fontFamily: "Arial, sans-serif",
      }}
    >
      <h2 style={{ textAlign: "center", color: "#4CAF50", marginBottom: "20px" }}>Enquiry Form</h2>

      <form onSubmit={handleSaveEnquiry}>
        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", fontWeight: "bold", marginBottom: "5px" }}>Name:</label>
          <input
            type="text"
            name="name"
            value={userDetails.name}
            onChange={handleChange}
            placeholder="Enter your name"
            style={{
              width: "100%",
              padding: "10px",
              border: "1px solid #ccc",
              borderRadius: "4px",
              fontSize: "14px",
            }}
          />
        </div>

        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", fontWeight: "bold", marginBottom: "5px" }}>Email:</label>
          <input
            type="email"
            name="email"
            value={userDetails.email}
            onChange={handleChange}
            placeholder="Enter your email"
            style={{
              width: "100%",
              padding: "10px",
              border: "1px solid #ccc",
              borderRadius: "4px",
              fontSize: "14px",
            }}
          />
        </div>

        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", fontWeight: "bold", marginBottom: "5px" }}>Message:</label>
          <textarea
            name="message"
            value={userDetails.message}
            onChange={handleChange}
            placeholder="Enter your message here"
            style={{
              width: "100%",
              padding: "10px",
              border: "1px solid #ccc",
              borderRadius: "4px",
              fontSize: "14px",
              resize: "none",
              height: "80px",
            }}
          ></textarea>
        </div>

        <button
          type="submit"
          style={{
            width: "100%",
            padding: "10px",
            backgroundColor: "#4CAF50",
            color: "white",
            border: "none",
            borderRadius: "4px",
            fontSize: "16px",
            cursor: "pointer",
          }}
        >
          Submit
        </button>
      </form>
    </div>
  );
}

export default UserDetailsForm;
