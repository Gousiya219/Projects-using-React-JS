import axios from "axios";
import React, { useEffect, useState } from "react";

function UserEnquiries() {
  const [enquiries, setEnquiries] = useState([]);
  const url = "http://localhost:8000/enquiries";

  useEffect(() => {
    axios.get(url).then((response) => {
      setEnquiries(response.data);
    });
  }, []);

  return (
    <div style={{ padding: "20px", maxWidth: "600px", margin: "auto", fontFamily: "Arial, sans-serif" }}>
      <h2 style={{ textAlign: "center", color: "#4CAF50", marginBottom: "20px" }}>User Enquiries</h2>
      {enquiries.map((enquiry, index) => (
        <div
          key={index}
          style={{
            border: "1px solid #ddd",
            borderRadius: "5px",
            padding: "15px",
            marginBottom: "10px",
            backgroundColor: "#f9f9f9",
            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
          }}
        >
          <p style={{ margin: "5px 0", fontWeight: "bold" }}>{enquiry.name}</p>
          <p style={{ margin: "5px 0", color: "#555" }}>{enquiry.email}</p>
          <p style={{ margin: "5px 0", fontStyle: "italic" }}>{enquiry.message}</p>
        </div>
      ))}
    </div>
  );
}

export default UserEnquiries;
