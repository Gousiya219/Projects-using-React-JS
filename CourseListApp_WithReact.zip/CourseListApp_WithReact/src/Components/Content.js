import React, { Component } from 'react'

export class Content extends Component {
  render() {
    return (
      <div>{this.props.Number}</div>
    )
  }
}

export default Content