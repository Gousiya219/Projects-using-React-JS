import React, { Component } from "react";
import Content from "./Content";

export class LoginPage extends Component {
  constructor(props) {
    super(props);

    this.state = {
      userName: "",
      rollNumber: null,
      errormessage: "",
    };
  }
  myChangeHandler = (event) => {
    let nam = event.target.name;
    let val = event.target.value;
    let err = "";
    if (nam === "roll_no") {
      if (val !== "" && !Number(val)) {
        err = <strong>Your roll number must be a number</strong>;
      }
    }
    this.setState({ errormessage: err });
    this.setState({ [nam]: val });
  };
  render() {
    return (
      <form>
        <h1>Hello {this.state.username} </h1>
        <p>Register your name:</p>
        <input
          type="text" //form type
          name="username"
          placeholder="Enter your name"
          onChange={this.myChangeHandler}
        />
        <p>Enter your roll_no:</p>
        <input
          type="text" //form type
          name="roll_no"
          placeholder="Enter your roll number"
          onChange={this.myChangeHandler}
        />
        {this.state.errormessage}
      </form>
    );
  }
}
export default LoginPage;
