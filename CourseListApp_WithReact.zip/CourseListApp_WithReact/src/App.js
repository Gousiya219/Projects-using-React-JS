import {
  BrowserRouter as Router,
  Routes,
  Route,
  NavLink,
  BrowserRouter,
} from "react-router-dom";
import CourseList from "./Components/CourseListApplication/CourseList";
import UserEnquiries from "./Components/CourseListApplication/UserEnquiries";
import UserDetailsForm from "./Components/CourseListApplication/UserDetailsForm";
import "./CourseListApp.css";

const App = () => {
  return (
    <BrowserRouter>
      <nav>
        <ul>
         
          <li>
            <NavLink to="/">CourseList</NavLink>
          </li>
          <li>
            <NavLink to="/user-details-form">User Details Form</NavLink>
          </li>
          <li>
            <NavLink to="/user-enquiries">User Enquiries</NavLink>
          </li>
        </ul>
      </nav>
      <Routes>
        <Route path="/" element={<CourseList />} />
        <Route path="/user-details-form" element={<UserDetailsForm />} />
        <Route path="/user-enquiries" element={<UserEnquiries />} />
      </Routes>
    </BrowserRouter>
    
  );
};

export default App;
