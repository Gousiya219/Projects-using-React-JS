// src/components/TodoItem.js
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const TodoItem = ({ todo, onDelete }) => {
  return (
    <View style={styles.item}>
      <Text style={styles.text}>{todo}</Text>
      <TouchableOpacity onPress={() => onDelete(todo)}>
        <Text style={styles.delete}>Delete</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  text: {
    fontSize: 18,
  },
  delete: {
    color: 'red',
    fontSize: 18,
  },
});

export default TodoItem;
