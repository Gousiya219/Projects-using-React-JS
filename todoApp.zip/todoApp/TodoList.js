// src/components/TodoList.js
import React from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import TodoItem from './TodoItem';

const TodoList = ({ todos, onDelete }) => {
  return (
    <ScrollView style={styles.list}>
      {todos.map((todo, index) => (
        <TodoItem key={index} todo={todo} onDelete={onDelete} />
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  list: {
    marginTop: 20,
  },
});

export default TodoList;
