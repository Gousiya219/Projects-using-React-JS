import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { fetchCourses } from "./actions/courseActions";

const CourseList = () => {
  const dispatch = useDispatch();
  const courses = useSelector((state) => state.courses.courses);

  useEffect(() => {
    dispatch(fetchCourses());
  }, [dispatch]);

  return (
    <div>
      <h2>Available Courses</h2>
      {courses.map((course) => (
        <div key={course.id}>
          <span>{course.courseName}</span>
          <Link to={`/user-details-form`}>
            <button>Enquire</button>
          </Link>
        </div>
      ))}
    </div>
  );
};

export default CourseList;
