const initialState = {
    enquiries: [],
  };
  
  const enquiriesReducer = (state = initialState, action) => {
    switch (action.type) {
      case "FETCH_ENQUIRIES_SUCCESS":
        return { ...state, enquiries: action.payload };
      case "ADD_ENQUIRY_SUCCESS":
        return { ...state, enquiries: [...state.enquiries, action.payload] };
      default:
        return state;
    }
  };
  
  export default enquiriesReducer;
  