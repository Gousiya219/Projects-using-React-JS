import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { fetchEnquiries } from "./actions/enquiryActions";

const EnquiryList = () => {
  const dispatch = useDispatch();
  const enquiries = useSelector((state) => state.enquiries.enquiries);

  useEffect(() => {
    dispatch(fetchEnquiries());
  }, [dispatch]);

  return (
    <div>
      <h2>Enquiries</h2>
      {enquiries.length > 0 ? (
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Course</th>
            </tr>
          </thead>
          <tbody>
            {enquiries.map((enquiry) => (
              <tr key={enquiry.id}>
                <td>{enquiry.name}</td>
                <td>{enquiry.email}</td>
                <td>{enquiry.course}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No enquiries found.</p>
      )}
    </div>
  );
};

export default EnquiryList;
