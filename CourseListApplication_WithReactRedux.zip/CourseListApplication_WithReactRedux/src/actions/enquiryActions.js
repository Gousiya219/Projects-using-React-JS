import axios from "axios";

export const fetchEnquiries = () => async (dispatch) => {
  try {
    const response = await axios.get("http://localhost:9000/enquiries");
    dispatch({ type: "FETCH_ENQUIRIES_SUCCESS", payload: response.data });
  } catch (error) {
    console.error("Error fetching enquiries:", error);
  }
};

export const addEnquiry = (enquiry) => async (dispatch) => {
  try {
    await axios.post("http://localhost:9000/enquiries", enquiry);
    dispatch({ type: "ADD_ENQUIRY_SUCCESS", payload: enquiry });
  } catch (error) {
    console.error("Error adding enquiry:", error);
  }
};
