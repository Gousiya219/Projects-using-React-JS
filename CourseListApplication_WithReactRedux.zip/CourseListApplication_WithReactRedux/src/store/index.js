import { createStore, applyMiddleware, combineReducers } from "redux";
import coursesReducer from "../reducers/coursesReducer";
import enquiriesReducer from "../reducers/enquiriesReducer";
import { thunk } from "redux-thunk";

const rootReducer = combineReducers({
  courses: coursesReducer,
  enquiries: enquiriesReducer,
});

const store = createStore(rootReducer, applyMiddleware(thunk));

export default store;
