import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import CourseList from "./CourseList";
import UserDetailsForm from "./UserDetailsForm";
import EnquiryList from "./EnquiryList";
import './App.css'; // Import CSS

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<CourseList />} />
        <Route path="/user-details-form" element={<UserDetailsForm />} />
        <Route path="/enquiries" element={<EnquiryList />} />
      </Routes>
    </Router>
  );
};

export default App;
